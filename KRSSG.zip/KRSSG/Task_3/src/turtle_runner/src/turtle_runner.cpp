#include<fstream>
#include<iostream>
#include<vector>
#include<stack>
#include"ros/ros.h"
#include"ros/package.h"
#include"ros/service.h"
#include"turtlesim/SetPen.h"
#include"geometry_msgs/Twist.h"
#define INF 70000;
const double PI=3.14159265359;

void turtle_move(double cur_angle,ros::Publisher &runn,double X,double Y);
void turtle_rotate(double angle,ros::Publisher &runn);

using namespace std;

struct Point{
        int x, y;
        Point operator-(Point &p)
        {
            Point result;
            result.x=x-p.x;
            result.y=y-p.y;
            return result;
        }
    };

int main(int argc,char **argv)
{
    char str[1000];
    int ROWS=0,COLS_MAX=0;
    vector<int> COLS;
    string path=ros::package::getPath("turtle_runner");
    path+="/src/text.txt";
    ifstream file(path.c_str());
    vector <vector <bool> > matrix;
    while(!file.getline(str,1000,'\n').eof())
    {
        vector <bool> lineData;
        for(int i=0;str[i]!='\0';i++)
        {
            if(str[i]=='0')
                lineData.push_back(false);
            else if(str[i]=='1') lineData.push_back(true);
        }
        if(lineData.size()>COLS_MAX) COLS_MAX=lineData.size();
        COLS.push_back(lineData.size());
        matrix.push_back(lineData);
        ROWS++;
    }
/*
    //DISPLAY MATRIX
    for(int i=0;i<ROWS;i++)
    {
        for(vector<bool>::iterator it=matrix[i].begin();it<matrix[i].end();it++)
        {
            cout<<*it<<" ";
        }
        cout<<"Cols: "<<COLS[i]<<" \n";
    }
    cout<<"Rows: "<<ROWS;*/

    //DIJKSTRA

    Point initialp={0,0},endp={ROWS-1,matrix[ROWS-1].size()-1},p=initialp;
    vector<vector<int> >dist(ROWS),visited(ROWS);
    for(int i=0;i<ROWS;i++)
    {
        dist[i].resize(COLS[i]);
        visited[i].resize(COLS[i]);
        for(int j=0;j<COLS[i];j++)
        {
            dist[i][j]=INF;
            visited[i][j]=0;
        }
    }
    //cout<<endp.x<<" "<<endp.y;
    dist[initialp.x][initialp.y]=0;

    while(!visited[endp.x][endp.y])
    {
        for(int i=-1;i<2;i++)
        {
            for(int j=-1;j<2;j++)
            {
                if(p.x+i>=0&&p.y+j>=0&&p.x+i<ROWS&&p.y+j<matrix[p.x+i].size())
                {
                    if(matrix[p.x+i][p.y+j]!=1&&!visited[p.x+i][p.y+j])
                    {
                        if((i+j)%2)
                        {
                            if(dist[p.x+i][p.y+j]>dist[p.x][p.y]+1)
                                dist[p.x+i][p.y+j]=dist[p.x][p.y]+1;

                        }
                    }
                }
            }
        }
        visited[p.x][p.y]=1;
        int mini=80000;
        for(int i=0;i<ROWS;i++)
            for(int j=0;j<COLS[i];j++)
            {
                if(mini>dist[i][j]&&!visited[i][j])
                {
                    mini=dist[i][j];
                    p.x=i;p.y=j;
                }
            }
    }
    //DIJKSTRA ENDS
    //DISPLAY DISTANCE MATRIX
  /*  for(int i=0;i<ROWS;i++){
        for(int j=0;j<COLS[i];j++)
            cout<<dist[i][j]<<" ";
            cout<<"\n";
            }*/

    stack <Point> marked;
    Point temp={endp.x,endp.y};
    marked.push(temp);
    int flag;
    while(marked.top().x!=initialp.x||marked.top().y!=initialp.y)
    {
        //cout<<temp.x<<" "<<temp.y<<"\n";
        flag=0;
        temp=marked.top();
        for(int i=-1;i<2;i++){
            for(int j=-1;j<2;j++)
            {
                if(temp.x+i>=0&&temp.y+j>=0&&temp.x+i<ROWS&&temp.y+j<matrix[temp.x+i].size())
                {
                    if((i+j)%2)
                    {
                        if(dist[temp.x][temp.y]==dist[temp.x+i][temp.y+j]+1)
                        {
                            marked.push({temp.x+i,temp.y+j});
                            flag=1;
                        }
                    }
                }
                if(flag==1)
                    break;
            }
            if(flag==1)
                break;
            }
    }
    //DISPLAY SPECIFIC MARKED PATH
    /*
    while(!marked.empty())
    {
        cout<<marked.top().x<<" "<<marked.top().y<<"\n";
        marked.pop();
    }*/

    vector<Point> diff_points;
    while(!marked.empty())
    {
        Point p1,p2;
        p1=marked.top();
        marked.pop();
        if(marked.empty())
            break;
        p2=marked.top();
        diff_points.push_back(p2-p1);
    }
    //DISPLAY TURTLE MOVEMENT PATHS
/*
    for(vector<Point>::iterator it=diff_points.begin();it<diff_points.end();it++)
        cout<<it->x<<" "<<it->y<<"\n";*/

    const float X=10.0/COLS_MAX,Y=10.0/ROWS;

    //ROS CODE

    ros::init(argc,argv,"runner");
    ros::NodeHandle n,nsrv;
    ros::Publisher runn=n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel",1000,true);
 //   ros::ServiceClient client = nsrv.serviceClient<turtlesim::SetPen>("/turtle1/set_pen");
    ros::Rate loop_rate(1);
//    turtlesim::SetPen srv;
  //  srv.request.off=1;
 //   if(!client.call(srv)) cout<<"error!";
    const float initial_angle=0;//3*PI/4+0.5;
    float cur_angle=3.0*PI/4.0 - 0.20;
    turtle_rotate(3*PI/4+0.5,runn);
   // ros::spinOnce();
    loop_rate.sleep();
    turtle_move(0,runn,6.4,6.4);
  //  ros::spinOnce();
    loop_rate.sleep();
   // turtle_rotate(-3*PI/4-0.5,runn);
  //  ros::spinOnce();
   // loop_rate.sleep();
   // srv.request.off=0;
   // if(!client.call(srv)) cout<<"error!";
    for(vector<Point>::iterator it=diff_points.begin();it<diff_points.end();it++)
    {
        if(it->x==0)
        {
            turtle_rotate((it->y)*(0-cur_angle),runn);
            cur_angle=((it->y)>=0)?0:PI;
            ros::spinOnce();
            loop_rate.sleep();
            turtle_move(cur_angle,runn,X,Y);
            ros::spinOnce();
            loop_rate.sleep();
        }
        else{
            turtle_rotate((it->x)*(3*PI/2)-cur_angle,runn);
            cur_angle=((it->x)>=0)?3*PI/2:PI/2;
            ros::spinOnce();
            loop_rate.sleep();
            turtle_move(cur_angle,runn,X,Y);
            ros::spinOnce();
            loop_rate.sleep();
        }
    }
    return 0;
}

const double timet=1,thres=PI/4;

void turtle_rotate(double angle,ros::Publisher &runn)
{
    geometry_msgs::Twist msg;
    msg.linear.x=0;
    msg.linear.y=0;
    msg.linear.z=0;
    msg.angular.x=0;
    msg.angular.y=0;
    msg.angular.z=angle/timet;
    ROS_INFO("I sent angular: [%f]\n",msg.angular.z);
    runn.publish(msg);
}

void turtle_move(double cur_angle,ros::Publisher &runn,double X,double Y)
{
    geometry_msgs::Twist msg;
    if(abs(cur_angle)<thres||abs(PI-cur_angle)<thres)
        msg.linear.x=X/timet;
    else msg.linear.x=Y/timet;
    msg.linear.y=0;
    msg.linear.z=0;
    msg.angular.x=0;
    msg.angular.y=0;
    msg.angular.z=0;
    ROS_INFO("I sent linear: [%f]\n",msg.linear.x);
    runn.publish(msg);
}
