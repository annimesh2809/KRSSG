#include<fstream>
#include<vector>

#include"ros/ros.h"
#include"std_msgs/Int32.h"
#include "ros/package.h"

using namespace std;

vector<int>result;
    void callBack(const std_msgs::Int32 &x)
    {
        string path=ros::package::getPath("simple_1");
        path+="/src/result.txt";
        ofstream file(path.c_str());
        ROS_INFO("\nI heard: [%d]",x.data);
        result.push_back(x.data);
        sort(result.begin(),result.end());
        for(vector<int>::iterator i=result.begin();i<result.end();i++)
        {
            file<<*i<<" ";
        }
        file.close();
    }
    int main(int argc,char **argv)
    {
        ros::init(argc,argv,"writer");
        ros::NodeHandle n;
        ros::Subscriber sub1=n.subscribe("nums1",100,callBack);
        ros::Subscriber sub2=n.subscribe("nums2",100,callBack);
        ros::spin();
        return 0;
    }


