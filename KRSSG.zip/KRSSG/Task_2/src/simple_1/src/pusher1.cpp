#include "ros/ros.h"
#include "ros/package.h"
#include "std_msgs/Int32.h"

#include <fstream>

using namespace std;

int main(int argc, char **argv)
{
    string path=ros::package::getPath("simple_1");
    path+="/src/text1.txt";
    ifstream file(path.c_str());
	ros::init(argc,argv,"pub1");
	ros::NodeHandle n1;
	ros::Publisher sender1=n1.advertise<std_msgs::Int32>("nums1",100,true);
	ros::Rate loop_rate(1);
	int num;
    std_msgs::Int32 nx;
	while(file>>num)
	{
        nx.data=num;
        ROS_INFO("%d ",num);
        sender1.publish(nx);
        ros::spinOnce();
        loop_rate.sleep();
	}
	file.close();
	return 0;
}

