#include "System.h"
#include "Spherical.h"
#include "Cylindrical.h"

#ifndef VECTOR_H
#define VECTOR_H

class Vector : public System<Vector>
{
    public:
        double x,y,z;
        Vector();
        Vector(double,double,double);
        Vector operator+(Vector);
        Vector operator-(Vector);
        Vector operator*(double);
        Vector chgorg(Vector);
        void input();
        void display(disp_type);
        double norm();
        double angle_x();
        double angle_y();
        double angle_z();
        Vector toVector();
        Spherical toSpherical();
        Cylindrical toCylindrical();
        ~Vector();
    protected:
    private:
};

Vector operator*(double,Vector);

template <class T,class U>
Vector operator+(T , U);


#endif // VECTOR_H
