#ifndef RUN_H
#define RUN_H

#include"Vector.h"
#include"Spherical.h"
#include"Cylindrical.h"
#include"Complex.h"
#include<stack>
#include<fstream>

using namespace std;

class Run
{
    public:
        Run();
        ~Run();
        void start();
    protected:
    private:
        fstream file;
        stack<Complex> C_Log;
        stack<Vector> V_Log;
        void Main_Menu();
        void System_Handler();
        void Greeting();
        void Log_Operator();
        void Complex_Menu();
        void Complex_Handler();
        void Vector_Handler(char,int);
        void Vector_Menu();
        void Vector_Disp(Vector);
};

#endif // RUN_H
