#ifndef SYSTEM_H
#define SYSTEM_H

#define UNDEFINED 0
#define PI 3.14159265359

enum systems {COMPLEX, SPHERICAL, CYLINDRICAL, VECTOR};
enum disp_type {NORMAL, NO_VAR, NEW_LINE};

class Vector;
class Spherical;
class Cylindrical;

template <class T>
class System
{
    public:
        System();
        virtual T operator+(T)=0;
        virtual T operator-(T)=0;
        virtual T operator*(double)=0;
        virtual T chgorg(T)=0;
        virtual void display(disp_type)=0;
        virtual Vector toVector()=0;
        virtual Spherical toSpherical()=0;
        virtual Cylindrical toCylindrical()=0;
        virtual void input()=0;
        ~System();
    protected:
    private:
};



#endif // SYSTEM_H
