#ifndef SPHERICAL_H
#define SPHERICAL_H

#include "System.h"
#include "Vector.h"


class Spherical : public System<Spherical>
{
    public:
        double r,theta,phi;
        Spherical();
        Spherical(double,double,double);
        Spherical operator+(Spherical);
        Spherical operator-(Spherical);
        Spherical operator*(double);
        Spherical chgorg(Spherical);
        void input();
        void display(disp_type);
        Vector toVector();
        Spherical toSpherical();
        Cylindrical toCylindrical();
        ~Spherical();
    protected:
    private:
};

#endif // SPHERICAL_H
