#ifndef CYLINDRICAL_H
#define CYLINDRICAL_H

#include "System.h"


class Cylindrical : public System<Cylindrical>
{
    public:
        double r,theta,z;
        Cylindrical();
        Cylindrical(double,double,double);
        Cylindrical operator+(Cylindrical);
        Cylindrical operator-(Cylindrical);
        Cylindrical operator*(double);
        Cylindrical chgorg(Cylindrical);
        void input();
        void display(disp_type);
        Vector toVector();
        Spherical toSpherical();
        Cylindrical toCylindrical();
        ~Cylindrical();
    protected:
    private:
};

#endif // CYLINDRICAL_H
