#ifndef COMPLEX_H
#define COMPLEX_H

#define PI 3.14159265359

enum complex_disp_type { CARTESIAN, POLAR };

class Complex
{
    public:
        Complex();
        Complex(double,double);
        double re,im;
        double norm();
        double arg();
        Complex operator+(Complex);
        Complex operator-(Complex);
        Complex operator*(double);
        Complex operator*(Complex);
        Complex operator/(Complex);
        Complex operator/(double);
        Complex conj();
        void display(complex_disp_type);
        void input(complex_disp_type);
        ~Complex();
    protected:
    private:
};

Complex operator*(double,Complex);
Complex operator/(double,Complex);

#endif // COMPLEX_H
