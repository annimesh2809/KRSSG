#include "System.h"
#include"Vector.h"
#include"Spherical.h"
#include<iostream>

using namespace std;

template <class T>
System<T>::System()
{
    //ctor
}

template <class T>
System<T>::~System()
{
    //dtor
}


template class System<Vector>;
template class System<Spherical>;
template class System<Cylindrical>;
