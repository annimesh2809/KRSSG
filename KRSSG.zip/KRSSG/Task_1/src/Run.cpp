#include "Run.h"
#include<iostream>


using namespace std;

Run::Run()
{
    file.open("KRSSG.txt",ios::app);
}

Run::~Run()
{
    file.close();
}

void Run::Main_Menu()
{
    int opt;
    cout<<"\n**********************  MAIN MENU  ***********************";
    cout<<"\n**  1) Perform Operations                               **";
    cout<<"\n**  2) View Log                                         **";
    cout<<"\n**  3) Instructions                                     **";
    cout<<"\n**  4) Exit                                             **";
    cout<<"\n**                                                      **";
    cout<<"\n**********************************************************\n";
    cout<<"\n   Enter option number : ";
    cin>>opt;
    switch(opt)
    {
        case 1:
            System_Handler();
            break;
        case 2:
            Log_Operator();
            break;
        case 3:
            cout<<"\nThis is a basic coordinate system application for interconvresion and basic operations over (C)omplex,(c)ylindrical,(s)pherical and (v)ector systems.";
            cout<<"\nIt can store multiple coordinates and can perform operations over all instances if possible, storing the result for further use.";
            cout<<"\nMemory can be erased if required.";
            Main_Menu();
            break;
        case 4:
            return;
        default:
            cout<<"\nInvalid operation entered! Retry!";
            Main_Menu();
    }
}

void Run::System_Handler()
{
    char sys;
    cout<<"\nEnter system type and data : (C/c/s/v) \nC: Complex number system\nc: Cylindrical System\ns: Spherical System\nv: Vector System\n";
    cin>>sys;
    switch(sys)
    {
        case 'C':
            Complex_Handler();
            break;
        case 'c': case 's': case 'v':
            Vector_Handler(sys,1);
            break;
        default: cout<<"\nInvalid data type! Retry!";
                 System_Handler();
    }
    return;
}

void Run::Vector_Handler(char sys,int opt=1)
{
    switch(sys)
    {
        case 's':
        {
            Spherical sp;
            sp.input();
            V_Log.push(sp.toVector());
            break;
        }
        case 'c':
        {
            Cylindrical cy;
            cy.input();
            V_Log.push(cy.toVector());
            break;
        }
        case 'v':
        {
            Vector ve;
            ve.input();
            V_Log.push(ve);
            break;
        }
        default:
            cout<<"\nInvalid data type! Error! Retry ";

    }
    if(opt)
        Vector_Menu();
    return;
}

void Run::Vector_Menu()
{
    int opt;
    cout<<"\n******************  COORDINATE MENU  ********************";
    cout<<"\n** 1) Enter another coordinate                         **";
    cout<<"\n** 2) Add coordinates                                  **";
    cout<<"\n** 3) Convert to another system                        **";
    cout<<"\n** 4) Subtract recent coordinates                      **";
    cout<<"\n** 5) Scalar Multiply                                  **";
    cout<<"\n** 6) Change Origin                                    **";
    cout<<"\n** 7) Show all entered vectors                         **";
    cout<<"\n** 8) Display modulus and angles                       **";
    cout<<"\n** 9) Clear Memory                                     **";
    cout<<"\n** 0) Back to Main Menu                                **";
    cout<<"\n*********************************************************\n";
    cin>>opt;
    switch(opt)
    {
        case 1:
            {
                char sys;
                cout<<"\nEnter system type and data: (c/s/v) ";
                cin>>sys;
                Vector_Handler(sys);
                break;
            }
        case 2:
            {
                Vector result(0,0,0);
                while(!V_Log.empty())
                {
                    result=result+V_Log.top();
                    V_Log.pop();
                }
                V_Log.push(result);
                Vector_Disp(result);
                Vector_Menu();
                break;
            }
        case 3:
            {
                stack<Vector>temp;
                Vector result;
                while(!V_Log.empty())
                {
                    V_Log.top().display(NORMAL);
                    Vector_Disp(V_Log.top());
                    temp.push(V_Log.top());
                    V_Log.pop();
                }
                while(!temp.empty())
                {
                    V_Log.push(temp.top());
                    temp.pop();
                }
                Vector_Menu();
                break;
            }
        case 4:
            {
                Vector v1,v2;
                if(!V_Log.empty())
                {
                v1=V_Log.top();
                V_Log.pop();
                if(!V_Log.empty())
                {
                    v2=V_Log.top();
                    V_Log.pop();
                    Vector result=v2-v1;
                    Vector_Disp(result);
                    V_Log.push(result);
                }
                else{
                    cout<<"\nOnly one number present! Retry ";
                    V_Log.push(v1);
                }
                }
                else{
                    cout<<"\nNo numbers present! Retry ";
                }
                Vector_Menu();
                break;
            }
        case 5:
            {
                Vector result;
                double con;
                stack<Vector> temp;
                cout<<"\nEnter scalar: ";
                cin>>con;
                while(!V_Log.empty())
                {
                    result=V_Log.top()*con;
                    Vector_Disp(result);
                    temp.push(result);
                    V_Log.pop();
                }
                while(!temp.empty())
                {
                    V_Log.push(temp.top());
                    temp.pop();
                }
                Vector_Menu();
                break;
            }
        case 6:
            {
                char sys;
                stack<Vector>temp;
                cout<<"\nEnter system type and data of new origin: (c/s/v) ";
                cin>>sys;
                Vector_Handler(sys,0);
                Vector neworg=V_Log.top();
                V_Log.pop();
                Vector result;
                while(!V_Log.empty())
                {
                    result=V_Log.top().chgorg(neworg);
                    Vector_Disp(result);
                    temp.push(result);
                    V_Log.pop();
                }
                while(!temp.empty())
                {
                    V_Log.push(temp.top());
                    V_Log.pop();
                }
                Vector_Menu();
                break;
            }
        case 7:
            {
                stack<Vector>temp;
                while(!V_Log.empty())
                {
                    temp.push(V_Log.top());
                    Vector_Disp(V_Log.top());
                    V_Log.pop();
                }
                while(!temp.empty())
                {
                    V_Log.push(temp.top());
                    temp.pop();
                }
                Vector_Menu();
                break;
            }
        case 8:
            {
                stack<Vector>temp;
                while(!V_Log.empty())
                {
                    V_Log.top().display(NORMAL);
                    temp.push(V_Log.top());
                    cout<<"Magnitude: "<<V_Log.top().norm()<<" Angle x: "<<V_Log.top().angle_x()<<" Angle y: "<<V_Log.top().angle_y()<<" Angle z: "<<V_Log.top().angle_z()<<"\n";
                    V_Log.pop();
                }
                while(!temp.empty())
                {
                    V_Log.push(temp.top());
                    temp.pop();
                }
                Vector_Menu();
                break;
            }
        case 9:
            {
                while(!V_Log.empty())
                {
                    V_Log.pop();
                }
                Vector_Menu();
                break;
            }
        case 0:
            {
                Main_Menu();
                return;
            }
    }
}

void Run::Vector_Disp(Vector v)
{
    char opt;
    cout<<"\nEnter which coordinate system you want to display result? (c/s/v) ";
    cin>>opt;
    switch(opt)
    {
        case 'c':
            v.toCylindrical().display(NORMAL);
            break;
        case 's':
            v.toSpherical().display(NORMAL);
            break;
        case 'v':
            v.display(NORMAL);
            break;
        default:
            cout<<"\nError! Unknown display type! Retry!";
            Vector_Disp(v);
    }
    return;
}

void Run::Complex_Handler()
{
    char opt;
    Complex c1;
    cout<<"\nCartesian / Polar (C/P)? ";
    cin>>opt;
    if(opt=='C')
        c1.input(CARTESIAN);
    else if(opt=='P')
        c1.input(POLAR);
    else {
        cout<<"\nInvalid type! Retry!";
        Complex_Handler();
    }
    C_Log.push(c1);
    Complex_Menu();
}

void Run::Log_Operator()
{
    int opt;
    cout<<"\n**********************  LOG MENU  ************************";
    cout<<"\n** 1)View Log entries                                   **";
    cout<<"\n** 2)Delete entry(ies) from Log                         **";
    cout<<"\n** 3)Save Log entry(ies) to file                        **";
    cout<<"\n** 0)Back to Main Menu                                  **";
    cout<<"\n**********************************************************\n";
    cout<<"\n  Enter option number: ";
    cin>>opt;
    switch(opt)
    {
        case 1: break;
        case 2: break;
        case 3: break;
        default: break;
    }
}

void Run::Complex_Menu()
{
    int opt;
    cout<<"\n********************  COMPLEX MENU  **********************";
    cout<<"\n** 1) Enter another complex number                      **";
    cout<<"\n** 2) Add complex numbers                               **";
    cout<<"\n** 3) Subtract recent numbers                           **";
    cout<<"\n** 4) Multiply complex numbers                          **";
    cout<<"\n** 5) Divide recent complex numbers                     **";
    cout<<"\n** 6) Display polar form of numbers                     **";
    cout<<"\n** 7) Display entered numbers                           **";
    cout<<"\n** 8) Clear Memory                                      **";
    cout<<"\n** 0) Back to Main Menu                                 **";
    cout<<"\n**********************************************************\n";
    cout<<"\nEnter option number: ";
    cin>>opt;
    switch(opt)
    {
        case 1:
            Complex_Handler();
            break;
        case 2:
            {
                Complex result(0,0);
                while(!C_Log.empty())
                {
                    result=result+C_Log.top();
                    C_Log.pop();
                }
                result.display(CARTESIAN);
                C_Log.push(result);
                Complex_Menu();
                break;
            }
        case 3:
            {
                Complex c1,c2;
                if(!C_Log.empty())
                {
                c1=C_Log.top();
                C_Log.pop();
                if(!C_Log.empty())
                {
                    c2=C_Log.top();
                    C_Log.pop();
                    Complex result;
                    result=c2-c1;
                    result.display(CARTESIAN);
                    C_Log.push(result);
                    Complex_Menu();
                }
                else
                {
                    cout<<"\nOnly one number present! Retry: ";
                    C_Log.push(c1);
                    Complex_Handler();
                }
                }
                else{
                    cout<<"\nNo numbers present! Retry: ";
                    Complex_Handler();
                }
                break;
            }
        case 4:
            {
                Complex result(1,0);
                while(!C_Log.empty())
                {
                    result=result*C_Log.top();
                    C_Log.pop();
                }
                result.display(CARTESIAN);
                C_Log.push(result);
                Complex_Menu();
                break;
            }
        case 5:
            {
                Complex c1,c2;
                if(!C_Log.empty())
                {
                c1=C_Log.top();
                C_Log.pop();
                if(!C_Log.empty())
                {
                    c2=C_Log.top();
                    C_Log.pop();
                    Complex result;
                    result=c2/c1;
                    result.display(CARTESIAN);
                    C_Log.push(result);
                    Complex_Menu();
                }
                else
                {
                    cout<<"\nOnly one number present! Retry: ";
                    C_Log.push(c1);
                    Complex_Handler();
                }
                }
                else{
                    cout<<"\nNo numbers present! Retry: ";
                    Complex_Handler();
                }
                break;
            }
        case 6:
            {
                stack<Complex>temp;
                while(!C_Log.empty())
                {
                    C_Log.top().display(CARTESIAN);
                    cout<<"=> ";
                    C_Log.top().display(POLAR);
                    cout<<"\n";
                    temp.push(C_Log.top());
                    C_Log.pop();
                }
                while(!temp.empty())
                {
                    C_Log.push(temp.top());
                    temp.pop();
                }
                Complex_Menu();
                break;
            }
        case 7:
            {
                stack<Complex>temp;
                while(!C_Log.empty())
                {
                    temp.push(C_Log.top());
                    C_Log.top().display(CARTESIAN);
                    C_Log.pop();
                }
                while(!temp.empty())
                {
                    C_Log.push(temp.top());
                    temp.pop();
                }
                Complex_Menu();
                break;
            }
        case 8:
            {
                while(!C_Log.empty())
                {
                    C_Log.pop();
                }
                Complex_Menu();
                break;
            }
        case 0:
            {
                Main_Menu();
                break;
            }
        default:
            cout<<"\nError! Invalid option! Retry!";
            Complex_Menu();
    }
}

void Run::Greeting()
{
    cout<<"\nThank you for using it!\nMade by Animesh Kashyap for KRSSG Task-I\n";
}

void Run::start()
{
    Main_Menu();
    Greeting();
}
