#include "Cylindrical.h"
#include"Vector.h"
#include<math.h>
#include<iostream>

using namespace std;


Cylindrical::Cylindrical()
{
    //ctor
}

Cylindrical::Cylindrical(double a,double b,double c):r(a),theta(b),z(c)
{

}

Cylindrical::~Cylindrical()
{
    //dtor
}

Cylindrical Cylindrical::operator+(Cylindrical ob)
{
    Vector u=this->toVector();
    Vector v=ob.toVector();
    Vector result=u+v;
    return result.toCylindrical();
}

Cylindrical Cylindrical::operator-(Cylindrical ob)
{
    Vector u=this->toVector();
    Vector v=ob.toVector();
    Vector result=u-v;
    return result.toCylindrical();
}

Cylindrical Cylindrical::operator*(double con)
{
    Vector u=this->toVector();
    Vector result=u*con;
    return result.toCylindrical();
}

Cylindrical Cylindrical::chgorg(Cylindrical neworg)
{
    Vector u=this->toVector();
    Vector v=neworg.toVector();
    Vector result=u.chgorg(v);
    return result.toCylindrical();
}

Vector Cylindrical::toVector()
{
    Vector v;
    v.x=r*cos(theta);
    v.y=r*sin(theta);
    v.z=z;
    return v;
}

Spherical Cylindrical::toSpherical()
{
    return this->toVector().toSpherical();
}

void Cylindrical::display(disp_type opt)
{
    switch(opt)
    {
        case NORMAL:
            cout<<"r: "<<r<<" theta: "<<theta<<" z: "<<z<<endl; break;
        case NO_VAR:
            cout<<"("<<r<<","<<theta<<","<<z<<")"<<endl; break;
        case NEW_LINE:
            cout<<"r: "<<r<<"\ntheta: "<<theta<<"\nz: "<<z<<endl; break;
    }
}

Cylindrical Cylindrical::toCylindrical()
{
    return *this;
}

void Cylindrical::input()
{
    cout<<"r: ";
    cin>>r;
    cout<<"theta: ";
    cin>>theta;
    cout<<"z: ";
    cin>>z;
    cout<<"\n";
}
