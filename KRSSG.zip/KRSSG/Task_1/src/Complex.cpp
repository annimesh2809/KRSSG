#include "Complex.h"
#include<math.h>
#include<iostream>

using namespace std;

Complex::Complex()
{
    //ctor
}

Complex::~Complex()
{
    //dtor
}

Complex::Complex(double x,double y): re(x),im(y)
{

}

Complex Complex::operator+(Complex c)
{
    Complex result;
    result.re=this->re+c.re;
    result.im=this->im+c.im;
    return result;
}

Complex Complex::operator-(Complex c)
{
    Complex result;
    result.re=this->re-c.re;
    result.im=this->im-c.im;
    return result;
}

Complex Complex::operator*(double con)
{
    Complex result;
    result.re=this->re*con;
    result.im=this->im*con;
    return result;
}

Complex Complex::operator/(double con)
{
    Complex result;
    result.re=this->re/con;
    result.im=this->im/con;
    return result;
}

Complex operator*(double con,Complex c)
{
    Complex result;
    result.re=c.re*con;
    result.im=c.im*con;
    return result;
}

Complex Complex::conj()
{
    Complex result;
    result.re=re;
    result.im=-im;
    return result;
}

double Complex::norm()
{
    return sqrt(re*re+im*im);
}

double Complex::arg()
{
    if(re!=0)
        return atan(im/re);
    else if(im!=0) return PI/2;
    else return NAN;
}

void Complex::display(complex_disp_type opt)
{
    if(opt==CARTESIAN)
        if(im>=0)
            cout<<re<<" + i"<<im<<endl;
        else cout<<re<<" - i"<<-im<<endl;
    else if(opt==POLAR)
        cout<<"r: "<<norm()<<" theta: "<<arg();
}

Complex Complex::operator*(Complex c)
{
    Complex result;
    result.re=re*c.re-im*c.im;
    result.im=re*c.im+im*c.re;
    return result;
}

Complex Complex::operator/(Complex c)
{
    c=c.conj();
    Complex result=*this * c;
    if(c.norm()!=0)
        result=result/pow(c.norm(),2);
    else result={NAN,NAN};
    return result;
}

Complex operator/(double con,Complex c)
{
    Complex temp;
    temp.re=con;
    temp.im=0;
    return temp/c;
}

void Complex::input(complex_disp_type opt)
{
    if(opt==CARTESIAN)
    {
        cout<<"Re: ";
        cin>>re;
        cout<<"Im: ";
        cin>>im;
        cout<<"\n";
    }
    else if(opt==POLAR)
    {
        double r,theta;
        cout<<"r: ";
        cin>>r;
        cout<<"theta: ";
        cin>>theta;
        cout<<"\n";
        re=r*cos(theta);
        im=r*sin(theta);
    }
}
