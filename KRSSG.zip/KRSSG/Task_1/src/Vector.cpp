#include "Vector.h"
#include"Spherical.h"
#include<iostream>
#include<math.h>

using namespace std;

Vector::Vector()
{
    //ctor
}

Vector::Vector(double a, double b, double c)
: x(a),y(b),z(c)
{
    //ctor
}

Vector::~Vector()
{
    //dtor
}

Vector Vector::operator+(Vector ob)
{
    Vector result;
    result.x=x+ob.x;
    result.y=y+ob.y;
    result.z=z+ob.z;
    return result;
}

Vector Vector::operator-(Vector ob)
{
    Vector result;
    result.x=x-ob.x;
    result.y=y-ob.y;
    result.z=z-ob.z;
    return result;
}

Vector Vector::operator*(double con)
{
    Vector result;
    result.x=x*con;
    result.y=y*con;
    result.z=z*con;
    return result;
}

void Vector::display(disp_type opt)
{
    switch(opt)
    {
        case NORMAL:
            cout<<"x: "<<x<<" y: "<<y<<" z: "<<z<<endl; break;
        case NO_VAR:
            cout<<"("<<x<<","<<y<<","<<z<<")"<<endl; break;
        case NEW_LINE:
            cout<<"x: "<<x<<"\ny: "<<y<<"\nz: "<<z<<endl; break;
    }
}

Vector Vector::chgorg(Vector neworg)
{
    Vector result;
    result.x=x-neworg.x;
    result.y=y-neworg.y;
    result.z=z-neworg.z;
    return result;
}

Vector operator*(double con,Vector v)
{
    Vector result;
    result.x=con*v.x;
    result.y=con*v.y;
    result.z=con*v.z;
    return result;
}

double Vector::norm()
{
    return sqrt(x*x+y*y+z*z);
}

double Vector::angle_x()
{
    if(norm()==0)
        return UNDEFINED;
    else return acos(x/norm());
}

double Vector::angle_y()
{
    if(norm()==0)
        return UNDEFINED;
    else return acos(y/norm());
}

double Vector::angle_z()
{
    if(norm()==0)
        return UNDEFINED;
    else return acos(z/norm());
}

Spherical Vector::toSpherical()
{
    Spherical sp;
    sp.r=norm();
    sp.theta=angle_z();
    if(x!=0)
        sp.phi=atan(y/x);
    else sp.phi=PI/2;
    return sp;
}

Cylindrical Vector::toCylindrical()
{
    Cylindrical ob;
    ob.z=z;
    ob.r=sqrt(x*x+y*y);
    if(x!=0)
        ob.theta=atan(y/x);
    else ob.theta=PI/2;
    return ob;
}

Vector Vector::toVector()
{
    return *this;
}

template <class T,class U>
Vector operator+(T o1,U o2)
{
    Vector v1=o1.toVector();
    Vector v2=o2.toVector();
    Vector result=v1+v2;
    return result;
}

void Vector::input()
{
    cout<<"x: ";
    cin>>x;
    cout<<"y: ";
    cin>>y;
    cout<<"z: ";
    cin>>z;
    cout<<"\n";
}

template Vector operator+<Spherical,Cylindrical>(Spherical,Cylindrical);
template Vector operator+<Spherical,Vector>(Spherical,Vector);
template Vector operator+<Vector,Cylindrical>(Vector,Cylindrical);
template Vector operator+<Vector,Spherical>(Vector,Spherical);
template Vector operator+<Cylindrical,Vector>(Cylindrical,Vector);
template Vector operator+<Cylindrical,Spherical>(Cylindrical,Spherical);

