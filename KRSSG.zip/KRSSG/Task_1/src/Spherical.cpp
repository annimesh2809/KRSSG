#include "Spherical.h"
#include<iostream>
#include<math.h>

using namespace std;

Spherical::Spherical()
{
    //ctor
}

Spherical::Spherical(double a,double b,double c):r(a),theta(b),phi(c)
{

}

Spherical::~Spherical()
{
    //dtor
}

Spherical Spherical::operator+(Spherical ob)
{
    Vector u=this->toVector();
    Vector v=ob.toVector();
    Vector result=u+v;
    return result.toSpherical();
}

Spherical Spherical::operator-(Spherical ob)
{
    Vector u=this->toVector();
    Vector v=ob.toVector();
    Vector result=u-v;
    return result.toSpherical();
}

Spherical Spherical::operator*(double con)
{
    Vector u=this->toVector();
    Vector result=con*u;
    return u.toSpherical();
}

Spherical Spherical::chgorg(Spherical neworg)
{
    Vector u=this->toVector();
    Vector v=neworg.toVector();
    Vector result=u.chgorg(v);
    return result.toSpherical();
}

void Spherical::display(disp_type opt)
{
    switch(opt)
    {
        case NORMAL:
            cout<<"r: "<<r<<" theta: "<<theta<<" phi: "<<phi<<endl; break;
        case NO_VAR:
            cout<<"("<<r<<","<<theta<<","<<phi<<")"<<endl; break;
        case NEW_LINE:
            cout<<"r: "<<r<<"\ntheta: "<<theta<<"\nphi: "<<phi<<endl; break;
    }
}

Vector Spherical::toVector()
{
    Vector v;
    v.x=r*sin(theta)*cos(phi);
    v.y=r*sin(theta)*sin(phi);
    v.z=r*cos(theta);
    return v;
}

Cylindrical Spherical::toCylindrical()
{
    return this->toVector().toCylindrical();
}

Spherical Spherical::toSpherical()
{
    return *this;
}

void Spherical::input()
{
    cout<<"r: ";
    cin>>r;
    cout<<"theta: ";
    cin>>theta;
    cout<<"phi: ";
    cin>>phi;
    cout<<"\n";
}
