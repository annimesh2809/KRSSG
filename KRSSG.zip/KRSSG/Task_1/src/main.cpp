
#include<iostream>
#include"Run.h"

using namespace std;

int main()
{
    Run program;
    program.start();
}
